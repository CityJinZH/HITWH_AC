
// 判断前台页面是不是时光机页面
if(strPage() == "cross.html"){
    
    // 修复时光机页面右侧联系方式多出的空白
    $(".col.w-lg.bg-light.lter.bg-auto").attr("class","col w-lg bg-light lter");
}


